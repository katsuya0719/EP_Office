from django.apps import AppConfig


class HeatbalanceConfig(AppConfig):
    name = 'heatBalance'
